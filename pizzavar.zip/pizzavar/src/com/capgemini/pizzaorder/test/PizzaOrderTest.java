package com.capgemini.pizzaorder.test;

public class PizzaOrderTest {

}
