package com.capgemini.pizzaorder.bean;

import java.util.Date;


public class Pizza {

	private int orderid;
	private int customerId;
	private double totalPrice;
	private Date Orderdate;
	private  VegToppings toppings;
	
	public int getOrderid() {
		return orderid;
	}
	
	public Pizza() {
		super();
	}
	public void setOrderid(int orderid) {
		this.orderid = orderid;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Date getOrderdate() {
		return Orderdate;
	}
	public void setOrderdate(Date orderdate) {
		Orderdate = orderdate;
	}
	public VegToppings getToppings() {
		return toppings;
	}
	public void setToppings(VegToppings toppings) {
		this.toppings = toppings;
	}
	
	
	
	public Pizza(double totalPrice) {
		super();
		this.totalPrice = totalPrice;
	}
}
