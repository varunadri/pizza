package com.capgemini.pizzaorder.ui;

import java.util.Date;
import java.util.Random;
import java.util.Scanner;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.bean.VegToppings;
import com.capgemini.pizzaorder.exception.PizzaOrderException;
import com.capgemini.pizzaorder.service.IPizzaOrderService;
import com.capgemini.pizzaorder.service.PizzaOrderService;


public class Client {

	static Scanner sc=null;
	static Random rand=null;
	static Customer customer =null;
	static Pizza pizzaorder=null;
	static double totalPrize;
	static IPizzaOrderService ips= new PizzaOrderService();
	
	public static void main(String[] args) throws PizzaOrderException
	{
		sc=new Scanner(System.in);
		int choice;
		while(true)
		{
			System.out.println("-----------------------PIZZA SHOP---------------------------");
			
			System.out.println(" ");
			System.out.println("------------------------------------------------------------");
			System.out.println("Choose an operation");
			System.out.println("------------------------------------------------------------");
			System.out.println("1.  Place Oder");
			System.out.println("2.  Display Order");
			System.out.println("3. Exit");
			System.out.println(" ");
			System.out.println("-----------------------------------------------------------");

		choice=sc.nextInt();
		switch(choice){
		case 1: System.out.println("\n Enter Name of the customer: ");
		        String name=sc.next();
		        System.out.println("\n Enter customer address: ");
		        String address= sc.next();
		        System.out.println("\n Enter customer phone number: ");
		        String number=sc.next();
		        Customer customer= new Customer(address, name, number);
		        customer.setAddress(address);
		        customer.setCustomerName(name);
		        customer.setMobNo(number);
		        System.out.println("\n Type of pizza topping preferred: "
		        				 + "\n Capsicum "
		        				 + "\n Mushroom "
		        				 + "\n Jalapeno "
		        				 + "\n Paneer");
		        String topping=sc.next();
		        VegToppings vt=VegToppings.valueOf(topping);
		        Pizza pizza = new Pizza();
		        pizza.setToppings(vt);
		        
		        pizza.setOrderdate(new Date());
		        System.out.println("Order Date:"+pizza.getOrderdate());
		        
		        double price = ips.Calculateprice(pizza);
		        pizza.setTotalPrice(price);
		        System.out.println(" Price: "+ price);
		       /* int id= ips.placeOrder(customer, pizza);*/

				try{
					if(ips.isValidCustomer(customer)){
						
						 int id= ips.placeOrder(customer, pizza);
						/*System.out.println("Your Demand Draft request has been successfully registered along with the "+id);
						System.out.println("");*/
						
						   System.out.println(" Your Pizza Order is placed along with OrderID :"+id);
			
					}
					
				}catch(PizzaOrderException e){
					e.printStackTrace();
					System.out.println("Please try Again");
				}
				
				
				

		     
		        break;
		case 2: System.out.println("\n Enter OrerId: ");
		        int oid= sc.nextInt();
		        Pizza pizza1= ips.displayOrder(oid);
		        System.out.println("\n OrderId: "+ pizza1.getOrderid());
		        System.out.println("\n TotalPrice: "+ pizza1.getTotalPrice());
		        System.out.println("\n OrderDate: "+ pizza1.getOrderdate());
		        break;
		case 3: System.out.println("\n Exit"); System.exit(0);
        
        break;
        
		default: System.out.println("Invalid Choice..Try Again..!!");
        
			

		        
		        
		        
		}
		}
	}
}
