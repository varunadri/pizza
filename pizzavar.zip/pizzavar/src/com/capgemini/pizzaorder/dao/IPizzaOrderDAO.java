package com.capgemini.pizzaorder.dao;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaOrderException;

public interface IPizzaOrderDAO  {

	public int placeOrder(Customer customer,Pizza pizza) throws PizzaOrderException;
	public Pizza displayOrder(int orderid) throws PizzaOrderException;
	public double Calculateprice(Pizza pizza);
}
