package com.capgemini.pizzaorder.service;

import com.capgemini.pizzaorder.bean.Customer;
import com.capgemini.pizzaorder.bean.Pizza;
import com.capgemini.pizzaorder.exception.PizzaOrderException;
import com.capgemini.pizzaorder.dao.IPizzaOrderDAO;
import com.capgemini.pizzaorder.dao.PizzaOrderDAO;

public class PizzaOrderService implements IPizzaOrderService {

	static PizzaOrderDAO ipd= new PizzaOrderDAO(); ;
	
	@Override
	public boolean isValidCustomer(Customer customer) throws PizzaOrderException {
		 if(!customer.getMobNo().matches("[0-9]{10}")){
	 	    	throw new PizzaOrderException("Contact numner must be of 10 Digits..", null);
	 	    }
	 	    
	 	    if(customer.getCustomerName()==null||customer.getAddress()==null){
	 	    	throw new PizzaOrderException(" Name,Address must be filled.", null);
	 	    }
	 	   
		return true;
	}

	
	
	@Override
	public int placeOrder(Customer customer, Pizza pizza) throws PizzaOrderException {

		return ipd.placeOrder(customer,pizza);

	}

	@Override
	public Pizza displayOrder(int orderid) throws PizzaOrderException {

		return ipd.displayOrder(orderid);
	}

	@Override
	public double Calculateprice(Pizza pizza) {

		return ipd.Calculateprice(pizza);
	}

}
